/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.pipe.media

import android.hardware.camera2.CameraCharacteristics
import android.media.ImageReader
import android.os.Build
import android.view.Surface
import androidx.camera.camera2.pipe.CameraMetadata
import androidx.camera.camera2.pipe.CameraPipe
import androidx.camera.camera2.pipe.CameraStream
import androidx.camera.camera2.pipe.ImageSourceConfig
import androidx.camera.camera2.pipe.MemoryEstimator
import androidx.camera.camera2.pipe.OutputId
import androidx.camera.camera2.pipe.StreamFormat
import androidx.camera.camera2.pipe.StreamId
import androidx.camera.camera2.pipe.core.Log
import androidx.camera.camera2.pipe.core.Threads
import java.lang.Class
import javax.inject.Inject
import kotlinx.atomicfu.atomic

internal class ImageReaderImageSources
@Inject
constructor(
    private val threads: Threads,
    cameraPipeConfig: CameraPipe.Config,
    cameraMetadata: CameraMetadata,
    private val memoryEstimator: MemoryEstimator,
) : ImageSources {
    private val platformApiCompat = cameraPipeConfig.platformApiCompat

    // See: b/172464059
    //
    // The ImageReader has an internal limit of 64 images by design, but depending on the device
    // specific camera HAL (Which can be different per device) there is an additional number of
    // images that are reserved by the Camera HAL which reduces this number. If, for example,
    // the HAL reserves 8 images, you have a maximum of 56 (64 - 8).
    private val maxImageReaderCapacity by lazy {
        ImageReaderImageSource.BUFFER_QUEUE_MAX_CAPACITY -
            (cameraMetadata[CameraCharacteristics.REQUEST_PIPELINE_MAX_DEPTH]
                ?: ImageReaderImageSource.DEFAULT_PIPELINE_MAX_DEPTH)
    }

    override fun createImageSource(
        cameraStream: CameraStream,
        imageSourceConfig: ImageSourceConfig,
    ): ImageSource {
        return create(
            cameraStream,
            imageSourceConfig.capacity,
            imageSourceConfig.usageFlags,
            imageSourceConfig.defaultDataSpace,
            imageSourceConfig.defaultHardwareBufferFormat,
            imageSourceConfig.enableConcurrentOutputs,
        )
    }

    fun create(
        cameraStream: CameraStream,
        capacity: Int,
        usageFlags: Long?,
        defaultDataSpace: Int?,
        defaultHardwareBufferFormat: Int?,
        enableConcurrentOutputs: Boolean,
    ): ImageSource {
        require(cameraStream.outputs.isNotEmpty()) { "$cameraStream must have outputs." }
        require(capacity > 0) { "Capacity ($capacity) must be > 0" }
        if (enableConcurrentOutputs) {
            check(cameraStream.outputs.size > 1) {
                "Cannot enable concurrent outputs for a single output camera stream."
            }
        }

        val handlerProvider = { threads.camera2Handler }
        val executorProvider = { threads.lightweightExecutor }

        val imageReaderCapacity = clampImageReaderCapacity(capacity, maxImageReaderCapacity)

        if (cameraStream.outputs.size == 1) {
            val output = cameraStream.outputs.single()
            val handler = handlerProvider()
            val imageReader =
                AndroidImageReader.create(
                    output.size.width,
                    output.size.height,
                    output.format.value,
                    imageReaderCapacity,
                    usageFlags,
                    defaultDataSpace,
                    defaultHardwareBufferFormat,
                    cameraStream.id,
                    output.id,
                    handler,
                )
            return ImageReaderImageSource.create(imageReader, memoryEstimator)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val usage =
                if (usageFlags != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.BAKLAVA) {
                    usageFlags
                } else {
                    Log.warn {
                        "Ignoring usageFlags ($usageFlags) " +
                            "for $cameraStream. MultiResolutionImageReader does not support " +
                            "setting usage flags."
                    }
                    null
                }

            if (defaultDataSpace != null) {
                Log.warn {
                    "Ignoring DataSpace ($defaultDataSpace) " +
                        "for $cameraStream. MultiResolutionImageReader does not support " +
                        "setting the default DataSpace."
                }
            }
            if (defaultHardwareBufferFormat != null) {
                Log.warn {
                    "Ignoring HardwareBufferFormat ($defaultHardwareBufferFormat) " +
                        "for $cameraStream. MultiResolutionImageReader does not support " +
                        "setting the default HardwareBufferFormat."
                }
            }
            val imageReader =
                AndroidMultiResolutionImageReader.create(
                    cameraStream,
                    imageReaderCapacity,
                    executorProvider(),
                    usage,
                    enableConcurrentOutputs,
                    platformApiCompat,
                )
            return ImageReaderImageSource.create(imageReader, memoryEstimator)
        }

        // If we reach this point, it's likely the user asked for MultiResolutionImageReader
        // but it was not possible to create it due to the SDK the code is running on.
        throw IllegalStateException("Failed to create an ImageSource for $cameraStream!")
    }

    private fun clampImageReaderCapacity(desired: Int, maxImageReaderCapacity: Int): Int {
        // Increase the internal capacity of the ImageReader so that the final capacity of the
        // ImageSource matches the requested capacity.
        //
        // As an example, if the consumer requests "40", the ImageReader will be created with
        // a capacity of "42", which will allow the consumer to hold exactly 40 images without
        // stalling the camera pipeline.
        return maxOf(
            1 + ImageReaderImageSource.IMAGE_SOURCE_CAPACITY_MARGIN,
            minOf(
                desired + ImageReaderImageSource.IMAGE_SOURCE_CAPACITY_MARGIN,
                maxImageReaderCapacity,
            ),
        )
    }
}

/** An ImageReaderImageSource implements an [ImageSource] using an [ImageReader] */
public class ImageReaderImageSource(
    private val imageReader: ImageReaderWrapper,
    internal val maxImages: Int,
    internal val usageFlags: Long? = imageReader.usageFlags,
    private val memoryEstimator: MemoryEstimator,
) : ImageSource {
    public companion object {
        public const val BUFFER_QUEUE_MAX_CAPACITY: Int = 64
        public const val DEFAULT_PIPELINE_MAX_DEPTH: Byte = 10
        public const val IMAGE_SOURCE_CAPACITY_MARGIN: Int = 2

        public fun create(
            imageReader: ImageReaderWrapper,
            memoryEstimator: MemoryEstimator,
        ): ImageSource {
            // Reduce the maxImages of the ImageSource relative to the ImageReader to ensure there
            // is enough headroom to avoid acquiring too many images that could otherwise stall the
            // camera or trigger IllegalStateExceptions from the underlying ImageReader.
            val maxImages = imageReader.capacity - IMAGE_SOURCE_CAPACITY_MARGIN
            return ImageReaderImageSource(imageReader, maxImages, memoryEstimator = memoryEstimator)
        }
    }

    private val state = atomic(State.ACTIVE)
    private val imageCount = atomic(0)
    private val ImageWrapper.estimatedBytes: Long
        get() = StreamFormat.bytesPerImage(StreamFormat(format), width, height)

    override val surface: Surface = imageReader.surface

    override var imageListener: ImageListener? by atomic(null)
    override var expectedOutputsListener: ExpectedOutputsListener? by atomic(null)

    init {
        imageReader.onImageListener =
            ImageReaderWrapper.OnImageListener { streamId, outputId, image ->
                onImage(streamId, outputId, image)
            }
        imageReader.onExpectedOutputsListener =
            ImageReaderWrapper.OnExpectedOutputsListener { timestamp, outputIds ->
                expectedOutputsListener?.onExpectedOutputs(timestamp, outputIds)
            }
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : Any> unwrapAs(type: Class<T>): T? =
        when (type) {
            ImageReaderImageSource::class.java -> this as T?
            else -> imageReader.unwrapAs(type)
        }

    override fun close() {
        // If this is the first time this is invoked, update the state from ACTIVE to CLOSING and
        // flush unused images from the pool. This does *not* immediately close the underlying
        // ImageReader unless there are no outstanding images.
        if (state.compareAndSet(expect = State.ACTIVE, update = State.CLOSING)) {
            flushOrCloseIfEmpty()
        }
    }

    override fun toString(): String = "ImageSource($imageReader)"

    override fun discardFreeBuffers() {
        if (state.value == State.CLOSED) {
            Log.debug { "Calling discardFreeBuffers on $this on closed image source." }
            return
        }
        imageReader.discardFreeBuffers()
    }

    override fun flush() {
        if (state.value == State.CLOSED) {
            Log.debug { "Calling flush on $this on closed image source." }
            return
        }
        imageReader.flush()
    }

    private fun onImage(streamId: StreamId, outputId: OutputId, image: ImageWrapper) {
        // Always increment the imageCount before acquireNextImage
        val currentImageCount = imageCount.incrementAndGet()

        val outputListener = imageListener
        if (outputListener == null) {
            // If there is nowhere to send the image, close it and decrement the imageCount.
            closeAndDecrementImageCount(image)
            return
        }

        val isInactive = state.value != State.ACTIVE
        val isOverCapacity = currentImageCount > maxImages
        val isLowMemory = !memoryEstimator.canAllocate(image.estimatedBytes)
        // If there are too many images that are currently being held or the ImageSource is in
        // a CLOSING or CLOSED state, or we are low of memory budget: close the image, decrement the
        // imageCount, and let the outputListener know that an image was received but that it was
        // dropped (by passing null for the image).
        if (isOverCapacity || isInactive || isLowMemory) {
            when {
                isLowMemory ->
                    Log.warn {
                        "Dropping image from $streamId at ${image.timestamp} due to low memory budget. " +
                            "Usage: ${memoryEstimator.usage.value} bytes, requested: ${image.estimatedBytes} bytes."
                    }
                isInactive ->
                    Log.warn {
                        "Dropping image from $streamId at ${image.timestamp} because ImageSource is not active. " +
                            "State: ${state.value}."
                    }

                else ->
                    Log.warn {
                        "Dropping $image from $streamId, ${currentImageCount - 1} / $maxImages acquired."
                    }
            }
            val outputTimestamp = image.timestamp
            closeAndDecrementImageCount(image)
            outputListener.onImage(streamId, outputId, outputTimestamp, null)
            return
        }

        // Wrap and track the image, and pass it along to the outputListener, which is now
        // responsible for closing the image when it is done with it.
        outputListener.onImage(
            streamId,
            outputId,
            image.timestamp,
            TrackedOutputImage(this, image, streamId, outputId, memoryEstimator),
        )
    }

    internal fun closeAndDecrementImageCount(image: ImageWrapper) {
        // This must called *exactly* once for each image that is closed.
        image.close()
        imageCount.decrementAndGet()
        if (state.value != State.ACTIVE) {
            flushOrCloseIfEmpty()
        }
    }

    private fun flushOrCloseIfEmpty() {
        // Assumption: This method is ONLY called if the current state is CLOSING or CLOSED.
        if (state.value == State.CLOSED) {
            return
        }

        // If the imageCount is zero, or has just reached zero, update the state to CLOSED and call
        // close on the imageReader exactly once.
        if (imageCount.value == 0) {
            if (state.compareAndSet(State.CLOSING, State.CLOSED)) {
                imageReader.close()
            }
            return
        }

        // If we reach this point, this ImageSource is CLOSING. Actively flush and discard free
        // buffers to reduce memory usage as individual images are closed.
        imageReader.flush()
    }

    private enum class State {
        ACTIVE,
        CLOSING,
        CLOSED,
    }
}
