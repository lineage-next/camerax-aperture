/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.pipe

import androidx.camera.camera2.pipe.core.Log

internal class StrictMode(val enabled: Boolean) {
    inline fun check(value: Boolean, crossinline message: () -> String) {
        if (!value) {
            val failureMessage = message()
            if (!enabled) {
                Log.warn { failureMessage }
                return
            }
            throw IllegalStateException(failureMessage)
        }
    }
}
