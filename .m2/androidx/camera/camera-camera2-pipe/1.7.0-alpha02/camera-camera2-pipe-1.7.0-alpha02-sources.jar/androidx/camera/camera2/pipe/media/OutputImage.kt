/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.pipe.media

import androidx.camera.camera2.pipe.OutputId
import androidx.camera.camera2.pipe.StreamId
import java.lang.Class

/**
 * An OutputImage is a reference to an [ImageWrapper] that was produced from CameraPipe for a
 * specific [StreamId]/[OutputId] combination.
 */
public interface OutputImage : ImageWrapper {
    public val streamId: StreamId
    public val outputId: OutputId

    public companion object {
        public fun from(streamId: StreamId, outputId: OutputId, image: ImageWrapper): OutputImage {
            if (image is OutputImage) return image
            return OutputImageImpl(streamId, outputId, image)
        }

        private class OutputImageImpl(
            override val streamId: StreamId,
            override val outputId: OutputId,
            private val image: ImageWrapper,
        ) : ImageWrapper by image, OutputImage {
            @Suppress("UNCHECKED_CAST")
            override fun <T : Any> unwrapAs(type: Class<T>): T? =
                when (type) {
                    OutputImage::class.java -> this as T?
                    ImageWrapper::class.java -> this as T?
                    else -> image.unwrapAs(type)
                }

            override fun toString(): String = this.toLogString()
        }

        @Suppress("NOTHING_TO_INLINE")
        internal inline fun OutputImage.toLogString(): String {
            // Output Image will be written as "OutputImage-s42_o45-t1234567890" where
            // s42 is StreamId-42
            // o45 is OutputId-45
            // t1234567890 is the nanosecond timestamp of the image.
            return "OutputImage-s${streamId.value}_o${outputId.value}-t$timestamp"
        }
    }
}
