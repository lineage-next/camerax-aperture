/*
 * Copyright 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.pipe.compat

import android.annotation.SuppressLint
import android.app.admin.DevicePolicyManager
import android.hardware.camera2.CameraDevice.StateCallback
import android.hardware.camera2.CameraManager
import android.os.Build
import androidx.camera.camera2.pipe.CameraError
import androidx.camera.camera2.pipe.CameraId
import androidx.camera.camera2.pipe.CameraPipe
import androidx.camera.camera2.pipe.config.CameraPipeJob
import androidx.camera.camera2.pipe.core.Debug
import androidx.camera.camera2.pipe.core.Log
import androidx.camera.camera2.pipe.core.Threads
import androidx.camera.camera2.pipe.core.TimeSource
import androidx.camera.camera2.pipe.core.TimestampNs
import androidx.camera.camera2.pipe.core.Timestamps
import androidx.camera.camera2.pipe.core.Timestamps.formatMs
import androidx.camera.camera2.pipe.internal.CameraErrorListener
import java.util.concurrent.CopyOnWriteArrayList
import javax.inject.Inject
import javax.inject.Provider
import javax.inject.Singleton
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.channels.trySendBlocking
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.selects.onTimeout
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.supervisorScope

private val defaultCameraRetryTimeout = 10.seconds
private val activeResumeCameraRetryTimeout = 30.minutes

private val defaultCameraRetryDelay = 500.milliseconds

private val activeResumeCameraRetryDelayBase = defaultCameraRetryDelay

private val activeResumeCameraRetryThresholds =
    arrayOf(
        2.minutes, // 2m
        5.minutes, // 5m
    )

internal interface CameraOpener {
    suspend fun openCamera(cameraId: CameraId, stateCallback: StateCallback)
}

internal interface CameraAvailabilityMonitor {
    suspend fun startMonitoring(cameraId: CameraId): Session

    interface Session : AutoCloseable {
        suspend fun awaitAvailableCamera(timeout: Duration, cancelled: Deferred<Unit>): Boolean
    }
}

internal interface RetryingCameraStateOpener {
    suspend fun openCameraWithRetry(
        cameraId: CameraId,
        camera2DeviceCloser: Camera2DeviceCloser,
        isForegroundObserver: (Unit) -> Boolean = { _ -> true },
        cameraOpenAborted: Deferred<Unit> = CompletableDeferred(),
    ): OpenCameraResult

    fun openAndAwaitCameraWithRetry(
        cameraId: CameraId,
        camera2DeviceCloser: Camera2DeviceCloser,
    ): AwaitOpenCameraResult

    fun cancelOpen()
}

internal interface DevicePolicyManagerWrapper {
    val camerasDisabled: Boolean
}

internal class Camera2CameraOpener
@Inject
constructor(private val cameraManager: Provider<CameraManager>, private val threads: Threads) :
    CameraOpener {

    @SuppressLint(
        "MissingPermission" // Permissions are checked by calling methods.
    )
    override suspend fun openCamera(cameraId: CameraId, stateCallback: StateCallback) {
        val instance = cameraManager.get()
        Debug.trace("$cameraId#openCamera") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                Api28Compat.openCamera(
                    instance,
                    cameraId.value,
                    threads.camera2Executor,
                    stateCallback,
                )
            } else {
                instance.openCamera(cameraId.value, stateCallback, threads.camera2Handler)
            }
        }
    }
}

internal class Camera2CameraAvailabilityMonitor
@Inject
constructor(
    private val cameraManager: Provider<CameraManager>,
    private val threads: Threads,
    @CameraPipeJob private val cameraPipeJob: Job,
) : CameraAvailabilityMonitor {

    private val availableCameraFlow = callbackFlow {
        val availabilityCallback =
            object : CameraManager.AvailabilityCallback() {
                override fun onCameraAvailable(cameraIdString: String) {
                    trySendBlocking(CameraId(cameraIdString))
                }
            }

        val manager = cameraManager.get()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Api28Compat.registerAvailabilityCallback(
                manager,
                threads.camera2Executor,
                availabilityCallback,
            )
        } else {
            manager.registerAvailabilityCallback(availabilityCallback, threads.camera2Handler)
        }

        awaitClose { manager.unregisterAvailabilityCallback(availabilityCallback) }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    override suspend fun startMonitoring(cameraId: CameraId): CameraAvailabilityMonitor.Session {

        return object : CameraAvailabilityMonitor.Session {
            private val scope =
                CoroutineScope(threads.backgroundDispatcher + SupervisorJob(cameraPipeJob))
            private val listeners = CopyOnWriteArrayList<CompletableDeferred<Unit>>()

            init {
                scope.launch {
                    availableCameraFlow.collect {
                        if (it == cameraId) {
                            Log.debug { "$it has become available! Notifying listeners..." }
                            for (listener in listeners) {
                                listener.complete(Unit)
                            }
                        }
                    }
                }
            }

            override suspend fun awaitAvailableCamera(
                timeout: Duration,
                cancelled: Deferred<Unit>,
            ): Boolean {
                val listener = CompletableDeferred<Unit>()
                listeners.add(listener)
                val success = select {
                    listener.onAwait { true }
                    cancelled.onJoin { false }
                    onTimeout(timeout) { false }
                }
                listeners.remove(listener)
                return success
            }

            override fun close() {
                scope.cancel()
            }
        }
    }
}

internal class AndroidDevicePolicyManagerWrapper
@Inject
constructor(private val devicePolicyManager: DevicePolicyManager) : DevicePolicyManagerWrapper {
    override val camerasDisabled: Boolean
        get() =
            Debug.trace("DevicePolicyManager#getCameraDisabled") {
                devicePolicyManager.getCameraDisabled(null)
            }
}

internal data class OpenCameraResult(
    val cameraState: AndroidCameraState? = null,
    val errorCode: CameraError? = null,
)

internal data class AwaitOpenCameraResult(
    val cameraDeviceWrapper: CameraDeviceWrapper? = null,
    val androidCameraState: AndroidCameraState? = null,
)

internal class CameraStateOpener
@Inject
constructor(
    private val cameraOpener: CameraOpener,
    private val camera2MetadataProvider: Camera2MetadataProvider,
    private val cameraErrorListener: CameraErrorListener,
    private val camera2Quirks: Camera2Quirks,
    private val camera2SystemState: Camera2SystemState,
    private val timeSource: TimeSource,
    private val cameraInteropConfig: CameraPipe.CameraInteropConfig?,
    private val threads: Threads,
) {
    private var cameraOpenCancelled = CompletableDeferred<Unit>()

    internal suspend fun tryOpenCamera(
        cameraId: CameraId,
        attempts: Int,
        requestTimestamp: TimestampNs,
        camera2DeviceCloser: Camera2DeviceCloser,
        audioRestrictionController: AudioRestrictionController,
    ): OpenCameraResult {
        val metadata = camera2MetadataProvider.getCameraMetadata(cameraId)
        val cameraState =
            AndroidCameraState(
                cameraId,
                metadata,
                attempts,
                requestTimestamp,
                timeSource,
                cameraErrorListener,
                camera2DeviceCloser,
                camera2Quirks,
                camera2SystemState,
                threads,
                audioRestrictionController,
                cameraInteropConfig?.cameraDeviceStateCallback,
                cameraInteropConfig?.cameraCaptureSessionListener,
            )

        // When opening cameras, there are a number of important factors to consider:
        //
        // 1. The openCamera() call can block indefinitely on buggy platforms. When this happens,
        //    this halts all camera opening and closing operations, and blocks shutdown.
        // 2. Even when openCamera() succeeds, the state callbacks may also not come back.
        // 2. There are important, unskippable camera handling routines following the call.
        // 3. The camera opening process can take an unexpectedly long amount of time, for example,
        //    on slow systems, or when opening remote proxy cameras.
        //
        // ---
        //
        // Given the factors, we deal with these issues by compartmentalizing the camera opening
        // process into 4 jobs:
        //
        // 1. Launch a job for the openCamera() call.
        // 2. Launch a job to collect state callback results from the framework.
        // 3. Launch a job for timeout and to intervene when openCamera() times out.
        // 4. Launch a job to force cancel camera opening with a timeout when shutdown is issued.
        //
        // The following utilizes select expressions to sequentially handle these events. When an
        // OpenCameraResult is received through select (from either job 1 or 2), consider the camera
        // opening process complete. When null is received, wait for further events .
        return supervisorScope {

            // Asynchronously invoke openCamera(), which can block.
            var cameraOpenDeferred: Deferred<OpenCameraResult?>? = async {
                try {
                    cameraOpener.openCamera(cameraId, cameraState)
                } catch (exception: Exception) {
                    Log.warn(exception) { "Failed to open $cameraId" }
                    cameraState.closeWith(exception)
                    OpenCameraResult(errorCode = CameraError.from(exception))
                }
                null
            }

            // Deferred job to collect results from the AndroidCameraState.
            var resultDeferred: Deferred<OpenCameraResult>? = async {
                val result = cameraState.state.first { it !is CameraStateUnopened }
                when (result) {
                    is CameraStateOpen -> OpenCameraResult(cameraState = cameraState)
                    is CameraStateClosing -> {
                        cameraState.close()
                        OpenCameraResult(errorCode = result.cameraErrorCode)
                    }

                    is CameraStateClosed -> {
                        cameraState.close()
                        OpenCameraResult(errorCode = result.cameraErrorCode)
                    }

                    is CameraStateUnopened -> {
                        cameraState.close()
                        throw IllegalStateException("Unexpected CameraState: $result")
                    }
                }
            }

            // Timeout job to monitor and cancel camera opening when it times out.
            var timeoutJob: Job? = launch { delay(CAMERA_OPEN_TIMEOUT) }

            // Cancellation job to await on the camera open cancellation signal and start a
            // timeout before cancelling camera opening with a timeout error.
            var cameraOpenCancelJob: Job? = launch {
                cameraOpenCancelled.await()
                delay(CAMERA_OPEN_CANCEL_TIMEOUT)
            }

            while (isActive) {
                try {
                    val result =
                        select<OpenCameraResult?> {
                            cameraOpenDeferred?.onAwait {
                                // openCamera() returned
                                cameraOpenDeferred = null
                                it
                            }

                            resultDeferred?.onAwait {
                                // Camera opening completed. We have an opened camera, or we
                                // received an error.
                                resultDeferred = null
                                it
                            }

                            timeoutJob?.onJoin {
                                // Camera opening timeout job completes.
                                timeoutJob = null
                                if (cameraOpenDeferred != null) {
                                    // We hit our timeout, but openCamera() hasn't returned. This
                                    // indicates that the camera framework is likely blocked.
                                    cameraState.close()
                                    OpenCameraResult(
                                        errorCode = CameraError.ERROR_CAMERA_OPEN_TIMEOUT
                                    )
                                } else {
                                    // openCamera() did return, wait for the state callback.
                                    null
                                }
                            }

                            cameraOpenCancelJob?.onJoin {
                                // Camera opening was canceled explicitly from shutdown procedures.
                                cameraOpenCancelJob = null
                                OpenCameraResult(errorCode = CameraError.ERROR_CAMERA_OPEN_TIMEOUT)
                            }
                        }
                    if (result != null) {
                        Log.info { "Camera open completed: $result" }

                        cameraOpenDeferred?.cancel()
                        resultDeferred?.cancel()
                        timeoutJob?.cancel()
                        cameraOpenCancelJob?.cancel()

                        return@supervisorScope result
                    }
                } catch (throwable: Throwable) {
                    Log.error(throwable) { "Unexpected throwable during camera opening!" }
                    throw throwable
                }
            }

            // This shouldn't happen - we don't cancel scopes until camera is closed. Return
            // an error result to make compiler happy.
            return@supervisorScope OpenCameraResult(errorCode = CameraError.ERROR_CAMERA_OPENER)
        }
    }

    internal fun cancelOpen() {
        cameraOpenCancelled.complete(Unit)
    }

    private companion object {
        // The timeout for the CameraManager.openCamera call itself. Note that this is the timeout
        // for making the call and waiting for the call to return, rather than waiting for the
        // whole camera opening process
        val CAMERA_OPEN_TIMEOUT = 3.seconds

        // The timeout for waiting for the camera open result to come back after camera open
        // cancellation is issued. This is needed because during shutdown, we need to abandon
        // camera opening attempts in a timely manner, and unfortunately state callbacks don't come
        // sometimes.
        val CAMERA_OPEN_CANCEL_TIMEOUT = 2.seconds
    }
}

@Singleton
internal class RetryingCameraStateOpenerImpl
@Inject
constructor(
    private val cameraStateOpener: CameraStateOpener,
    private val cameraErrorListener: CameraErrorListener,
    private val cameraAvailabilityMonitor: CameraAvailabilityMonitor,
    private val timeSource: TimeSource,
    private val devicePolicyManager: DevicePolicyManagerWrapper,
    private val audioRestrictionController: AudioRestrictionController,
    private val cameraInteropConfig: CameraPipe.CameraInteropConfig?,
    private val threads: Threads,
) : RetryingCameraStateOpener {
    override suspend fun openCameraWithRetry(
        cameraId: CameraId,
        camera2DeviceCloser: Camera2DeviceCloser,
        isForegroundObserver: (Unit) -> Boolean,
        cameraOpenAborted: Deferred<Unit>,
    ): OpenCameraResult {
        val requestTimestamp = Timestamps.now(timeSource)
        var attempts = 0

        cameraAvailabilityMonitor.startMonitoring(cameraId).use {
            while (true) {
                if (cameraOpenAborted.isCompleted) {
                    return OpenCameraResult(errorCode = CameraError.ERROR_CAMERA_OPEN_TIMEOUT)
                }

                attempts++

                val result =
                    cameraStateOpener.tryOpenCamera(
                        cameraId,
                        attempts,
                        requestTimestamp,
                        camera2DeviceCloser,
                        audioRestrictionController,
                    )
                val elapsed = Timestamps.now(timeSource) - requestTimestamp
                with(result) {
                    if (cameraState != null) {
                        return result
                    }

                    if (errorCode == null) {
                        // Camera open failed without an error. This can only happen if the
                        // VirtualCameraState is disconnected by the app itself. As such, we should
                        // just abandon the camera open attempt.
                        Log.warn {
                            "Camera open failed without an error. " +
                                "The CameraGraph may have been stopped or closed. " +
                                "Abandoning the camera open attempt."
                        }
                        return result
                    }

                    val isForeground = isForegroundObserver.invoke(Unit)
                    val willRetry =
                        shouldRetry(
                            errorCode,
                            attempts,
                            elapsed,
                            devicePolicyManager.camerasDisabled,
                            isForeground,
                            cameraInteropConfig?.cameraOpenRetryMaxTimeout,
                        )
                    // Always notify if the decision is to not retry the camera open, otherwise
                    // allow 1 open call to happen silently without generating an error, and notify
                    // about each error after that point.
                    if (!willRetry || attempts > 1) {
                        cameraErrorListener.onCameraError(cameraId, errorCode, willRetry)
                    }
                    if (!willRetry) {
                        Log.error {
                            "Failed to open camera $cameraId after $attempts attempts " +
                                "and ${(Timestamps.now(timeSource) - requestTimestamp).formatMs()}. " +
                                "Last error was $errorCode."
                        }
                        return result
                    }

                    if (cameraOpenAborted.isCompleted) {
                        return OpenCameraResult(errorCode = CameraError.ERROR_CAMERA_OPEN_TIMEOUT)
                    }
                    // Listen to availability - if we are notified that the cameraId is available
                    // then retry immediately.
                    if (
                        !it.awaitAvailableCamera(
                            timeout =
                                getRetryDelay(
                                    elapsed,
                                    shouldActivateActiveResume(isForeground, errorCode),
                                ),
                            cameraOpenAborted,
                        )
                    ) {
                        Log.debug { "Timeout expired, retrying camera open for camera $cameraId" }
                    }
                }
            }
        }
    }

    override fun openAndAwaitCameraWithRetry(
        cameraId: CameraId,
        camera2DeviceCloser: Camera2DeviceCloser,
    ): AwaitOpenCameraResult {
        Log.debug { "$this#openAndAwaitCameraWithRetry($cameraId)" }
        return runBlocking(threads.blockingDispatcher) {
            val androidCameraState = openCameraWithRetry(cameraId, camera2DeviceCloser).cameraState
            if (androidCameraState == null) {
                Log.error { "Failed to open $cameraId!" }
                return@runBlocking AwaitOpenCameraResult(null, null)
            }

            val cameraState = androidCameraState.state.first { it != CameraStateUnopened }
            if (cameraState is CameraStateOpen) {
                Log.info { "$cameraId opened successfully." }
                AwaitOpenCameraResult(cameraState.cameraDevice, androidCameraState)
            } else {
                Log.error { "Failed to open $cameraId!" }
                AwaitOpenCameraResult(null, null)
            }
        }
    }

    override fun cancelOpen() {
        cameraStateOpener.cancelOpen()
    }

    companion object {
        internal fun shouldRetry(
            errorCode: CameraError,
            attempts: Int,
            elapsed: Duration,
            camerasDisabledByDevicePolicy: Boolean,
            isForeground: Boolean = true,
            cameraOpenRetryMaxTimeout: Duration? = null,
        ): Boolean {
            val shouldActiveResume = shouldActivateActiveResume(isForeground, errorCode)
            if (shouldActiveResume) Log.debug { "shouldRetry: Active resume mode is activated" }
            if (elapsed > getRetryTimeout(shouldActiveResume, cameraOpenRetryMaxTimeout)) {
                return false
            }
            return when (errorCode) {
                CameraError.ERROR_UNDETERMINED ->
                    // The error indicates that the camera has encountered an undetermined error
                    // while the camera is being opened [1].
                    //
                    // This is an error that will be later informed through onError() [2], and will
                    // be returned as an actual error if the second camera open attempt also fails.
                    //
                    // [1] b/307411676 - IllegalArgumentException at
                    //                   CameraStateAdapter$Companion.toCameraStateError
                    // [2]
                    // https://developer.android.com/reference/android/hardware/camera2/CameraDevice.StateCallback#onError(android.hardware.camera2.CameraDevice,%20int)
                    attempts <= 1

                CameraError.ERROR_CAMERA_IN_USE ->
                    // The error indicates that camera is in use, possibly by an app with higher
                    // priority [1].
                    //
                    // Historically, we retry once to avoid polling for camera opens. Starting with
                    // the introduction of multi-resume on Android 10 (Q) however [2], it becomes
                    // easier to switch between apps, causing the issue to show up more prominently
                    // [3]. We therefore should retry continuously on Android OS versions >= Q.
                    //
                    // [1] b/38330838 - Cannot launch camera app during video call.
                    // [2] https://source.android.com/docs/core/display/multi_display/multi-resume
                    // [3] b/181777896 - Fatal error while switching between apps using camera.
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        attempts <= 1
                    } else {
                        true
                    }

                CameraError.ERROR_CAMERA_LIMIT_EXCEEDED -> true
                CameraError.ERROR_CAMERA_DISABLED ->
                    // The error indicates indicates that the current camera is currently disabled,
                    // either by a device level policy [1] or because the app isn't considered
                    // foreground (which can, under rare circumstances, happen when the app is
                    // actually in the foreground due to racey foreground status propagation in the
                    // Android Framework) [2]
                    //
                    // When cameras are disabled by policy, we retry just once in case we have a
                    // transient error, and only retry repeatedly if cameras aren't disabled by
                    // policy.
                    //
                    // [1] b/77827041 - Camera has been disabled because of security policies
                    // [2] b/250234453 - Fatal error encountered while switching camera app between
                    //                   foreground and background.
                    if (camerasDisabledByDevicePolicy) {
                        attempts <= 1
                    } else {
                        true
                    }

                CameraError.ERROR_CAMERA_DEVICE -> true
                CameraError.ERROR_CAMERA_SERVICE -> true
                CameraError.ERROR_CAMERA_DISCONNECTED -> true
                CameraError.ERROR_ILLEGAL_ARGUMENT_EXCEPTION -> true
                CameraError.ERROR_SECURITY_EXCEPTION -> attempts <= 1
                CameraError.ERROR_DO_NOT_DISTURB_ENABLED ->
                    // The error indicates that a RuntimeException was encountered when opening the
                    // camera while Do Not Disturb mode is on. This can happen on legacy devices on
                    // API level 28 [1]. Retries will always fail and should not be attempted.
                    //
                    // [1] b/149413835 - Crash during CameraX initialization when Do Not Disturb
                    //                   is on.
                    false

                CameraError.ERROR_UNKNOWN_EXCEPTION ->
                    // The error indicates that an unknown (undocumented) Exception has been thrown
                    // during the CameraManager.openCamera() call [1].
                    //
                    // The documentation states that only CameraAccessException,
                    // IllegalArgumentException and SecurityException can be thrown [2]. However, it
                    // seems that other Exceptions can also be thrown from a misbehaving camera HAL.
                    //
                    // [1] b/307387400 - Invalid (undocumented) exception during
                    //                   CameraManager.openCamera()
                    // [2]
                    // https://developer.android.com/reference/android/hardware/camera2/CameraManager#openCamera(java.lang.String,%20java.util.concurrent.Executor,%20android.hardware.camera2.CameraDevice.StateCallback)
                    attempts <= 1

                CameraError.ERROR_CAMERA_OPENER -> false
                CameraError.ERROR_CAMERA_OPEN_TIMEOUT -> false

                else -> {
                    Log.error { "Unexpected CameraError: $this" }
                    false
                }
            }
        }

        internal fun shouldActivateActiveResume(
            isForeground: Boolean,
            errorCode: CameraError,
        ): Boolean =
            isForeground &&
                Build.VERSION.SDK_INT in (Build.VERSION_CODES.Q..Build.VERSION_CODES.S_V2) &&
                (errorCode == CameraError.ERROR_CAMERA_IN_USE ||
                    errorCode == CameraError.ERROR_CAMERA_LIMIT_EXCEEDED ||
                    errorCode == CameraError.ERROR_CAMERA_DISCONNECTED)

        internal fun getRetryTimeout(
            activeResumeActivated: Boolean,
            cameraOpenRetryMaxTimeout: Duration? = null,
        ) =
            if (!activeResumeActivated) {
                min(defaultCameraRetryTimeout, cameraOpenRetryMaxTimeout)
            } else {
                min(activeResumeCameraRetryTimeout, cameraOpenRetryMaxTimeout)
            }

        internal fun getRetryDelay(elapsed: Duration, activeResumeActivated: Boolean): Duration {
            if (!activeResumeActivated) {
                return defaultCameraRetryDelay
            }
            return if (elapsed < activeResumeCameraRetryThresholds[0]) {
                activeResumeCameraRetryDelayBase
            } else if (elapsed < activeResumeCameraRetryThresholds[1]) {
                activeResumeCameraRetryDelayBase * 4
            } else {
                activeResumeCameraRetryDelayBase * 8
            }
        }

        private fun min(d1: Duration, d2: Duration?): Duration {
            if (d2 == null) {
                return d1
            }
            return if (d1 < d2) d1 else d2
        }
    }
}
