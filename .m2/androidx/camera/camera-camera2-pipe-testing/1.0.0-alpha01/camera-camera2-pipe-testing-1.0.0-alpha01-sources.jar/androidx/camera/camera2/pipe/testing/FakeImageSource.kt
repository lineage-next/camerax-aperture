/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.camera2.pipe.testing

import android.hardware.HardwareBuffer
import android.util.Size
import androidx.camera.camera2.pipe.MemoryEstimator
import androidx.camera.camera2.pipe.OutputId
import androidx.camera.camera2.pipe.StreamFormat
import androidx.camera.camera2.pipe.StreamId
import androidx.camera.camera2.pipe.media.ImageReaderImageSource
import androidx.camera.camera2.pipe.media.ImageSource
import kotlinx.atomicfu.atomic

public class FakeImageSource
private constructor(
    private val fakeImageReader: FakeImageReader,
    private val imageSource: ImageSource,
) : ImageSource by imageSource {
    private val debugId = debugIds.incrementAndGet()
    private val closed = atomic<Boolean>(false)
    public val isClosed: Boolean
        get() = closed.value

    public val streamId: StreamId
        get() = fakeImageReader.streamId

    /** Retrieve a list of every image that has been created from this FakeImageSource. */
    public val images: List<FakeImage>
        get() = fakeImageReader.images

    public val isFlushed: Boolean
        get() = fakeImageReader.isFlushed

    public fun simulateImage(
        timestamp: Long,
        outputId: OutputId? = null,
        hardwareBuffer: HardwareBuffer? = null,
    ): FakeImage {
        return fakeImageReader.simulateImage(timestamp, outputId, hardwareBuffer = hardwareBuffer)
    }

    public fun simulateExpectedOutputs(timestamp: Long, outputIds: Set<OutputId>) {
        fakeImageReader.simulateExpectedOutputs(timestamp, outputIds)
    }

    override fun close() {
        if (closed.compareAndSet(expect = false, update = true)) {
            imageSource.close()
        }
    }

    override fun toString(): String = "FakeImageSource-$debugId"

    override fun flush() {
        fakeImageReader.flush()
    }

    override fun discardFreeBuffers() {
        fakeImageReader.discardFreeBuffers()
    }

    public companion object {
        private val debugIds = atomic(0)

        public fun create(
            streamFormat: StreamFormat,
            streamId: StreamId,
            outputs: Map<OutputId, Size>,
            capacity: Int,
            usageFlags: Long?,
            fakeImageReaders: FakeImageReaders,
            memoryEstimator: MemoryEstimator,
        ): FakeImageSource {
            // ImageReaderImageSource maintains a margin to avoid acquiring too many images. We need
            // to bump up the capacity to keep effective capacity same.
            val fakeImageReader =
                fakeImageReaders.create(
                    streamFormat,
                    streamId,
                    outputs,
                    capacity + ImageReaderImageSource.IMAGE_SOURCE_CAPACITY_MARGIN,
                    usageFlags,
                )

            val imageReaderImageSource =
                ImageReaderImageSource.create(fakeImageReader, memoryEstimator)
            return FakeImageSource(fakeImageReader, imageReaderImageSource)
        }
    }
}
