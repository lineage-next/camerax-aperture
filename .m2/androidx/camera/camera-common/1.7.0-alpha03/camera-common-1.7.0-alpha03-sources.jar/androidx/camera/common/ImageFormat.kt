/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.camera.common

import androidx.annotation.IntDef
import androidx.annotation.RestrictTo

/**
 * Denotes that an integer represents an image format.
 *
 * This annotation represents a union of the image formats defined across multiple Android APIs,
 * allowing APIs in this library to accept format constants from:
 * * [android.graphics.ImageFormat]
 * * [android.graphics.PixelFormat]
 * * [android.hardware.HardwareBuffer]
 *
 * It also includes internal compatibility constants for newer formats that might not be present in
 * the compile SDK of the consuming application or library module.
 *
 * Use [ImageFormats] utility methods to inspect properties of these formats, such as
 * [ImageFormats.bitsPerPixel] or [ImageFormats.isRaw].
 *
 * @see android.graphics.ImageFormat
 * @see android.graphics.PixelFormat
 * @see android.hardware.HardwareBuffer
 * @see ImageFormats
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@Retention(AnnotationRetention.SOURCE)
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.FIELD,
    AnnotationTarget.LOCAL_VARIABLE,
    AnnotationTarget.VALUE_PARAMETER,
    AnnotationTarget.CONSTRUCTOR,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY_GETTER,
    AnnotationTarget.PROPERTY_SETTER,
    AnnotationTarget.TYPE,
)
@IntDef(
    value =
        [
            android.graphics.ImageFormat.UNKNOWN,
            android.graphics.ImageFormat.RGB_565,
            android.graphics.ImageFormat.YV12,
            android.graphics.ImageFormat.Y8,
            android.graphics.ImageFormat.NV16,
            android.graphics.ImageFormat.NV21,
            android.graphics.ImageFormat.YUY2,
            android.graphics.ImageFormat.JPEG,
            android.graphics.ImageFormat.DEPTH_JPEG,
            android.graphics.ImageFormat.YUV_420_888,
            android.graphics.ImageFormat.YUV_422_888,
            android.graphics.ImageFormat.YUV_444_888,
            android.graphics.ImageFormat.FLEX_RGB_888,
            android.graphics.ImageFormat.FLEX_RGBA_8888,
            android.graphics.ImageFormat.RAW_SENSOR,
            android.graphics.ImageFormat.RAW_PRIVATE,
            android.graphics.ImageFormat.RAW10,
            android.graphics.ImageFormat.RAW12,
            android.graphics.ImageFormat.DEPTH16,
            android.graphics.ImageFormat.DEPTH_POINT_CLOUD,
            android.graphics.ImageFormat.PRIVATE,
            android.graphics.ImageFormat.HEIC,
            android.graphics.ImageFormat.YCBCR_P010,
            android.graphics.ImageFormat.JPEG_R,
            IMAGE_FORMAT_RAW_DEPTH,
            IMAGE_FORMAT_RAW_DEPTH10,
            IMAGE_FORMAT_Y16,
            IMAGE_FORMAT_YCBCR_P210,
            IMAGE_FORMAT_HEIC_ULTRAHDR,
            IMAGE_FORMAT_R_8,
            IMAGE_FORMAT_HSV_888,
            IMAGE_FORMAT_R_16,
            IMAGE_FORMAT_RG_1616,
            IMAGE_FORMAT_RGBA_10101010,
            android.graphics.PixelFormat.UNKNOWN,
            android.graphics.PixelFormat.TRANSLUCENT,
            android.graphics.PixelFormat.TRANSPARENT,
            android.graphics.PixelFormat.OPAQUE,
            android.graphics.PixelFormat.RGBA_8888,
            android.graphics.PixelFormat.RGBX_8888,
            android.graphics.PixelFormat.RGB_888,
            android.graphics.PixelFormat.RGB_565,
            android.graphics.PixelFormat.RGBA_F16,
            android.graphics.PixelFormat.RGBA_1010102,
            android.hardware.HardwareBuffer.RGBA_8888,
            android.hardware.HardwareBuffer.RGBA_FP16,
            android.hardware.HardwareBuffer.RGBA_1010102,
            android.hardware.HardwareBuffer.RGBX_8888,
            android.hardware.HardwareBuffer.RGB_888,
            android.hardware.HardwareBuffer.RGB_565,
            android.hardware.HardwareBuffer.BLOB,
            android.hardware.HardwareBuffer.YCBCR_420_888,
            android.hardware.HardwareBuffer.D_16,
            android.hardware.HardwareBuffer.D_24,
            android.hardware.HardwareBuffer.DS_24UI8,
            android.hardware.HardwareBuffer.D_FP32,
            android.hardware.HardwareBuffer.DS_FP32UI8,
            android.hardware.HardwareBuffer.S_UI8,
            android.hardware.HardwareBuffer.YCBCR_P010,
        ]
)
public annotation class ImageFormat

// =============================================================================================
// Compatibility constants for formats that may be missing from the compile SDK.
// These are internal to the camera-common module.
// =============================================================================================

// Defined in frameworks/base/graphics/java/android/graphics/ImageFormat.java
// Link:
// https://cs.android.com/android/platform/superproject/main/+/main:frameworks/base/graphics/java/android/graphics/ImageFormat.java
internal const val IMAGE_FORMAT_RAW_DEPTH: Int = 0x1002
internal const val IMAGE_FORMAT_RAW_DEPTH10: Int = 0x1003
internal const val IMAGE_FORMAT_Y16: Int = 0x20363159
internal const val IMAGE_FORMAT_YCBCR_P210: Int = 0x3c // Also in HardwareBuffer.java
internal const val IMAGE_FORMAT_HEIC_ULTRAHDR: Int = 0x1006

// Defined in frameworks/base/graphics/java/android/graphics/PixelFormat.java
// Link:
// https://cs.android.com/android/platform/superproject/main/+/main:frameworks/base/graphics/java/android/graphics/PixelFormat.java
internal const val IMAGE_FORMAT_R_8: Int = 0x38 // Also in HardwareBuffer.java
internal const val IMAGE_FORMAT_HSV_888: Int = 0x37

// Defined in frameworks/base/core/java/android/hardware/HardwareBuffer.java
// Link:
// https://cs.android.com/android/platform/superproject/main/+/main:frameworks/base/core/java/android/hardware/HardwareBuffer.java
internal const val IMAGE_FORMAT_R_16: Int = 0x39
internal const val IMAGE_FORMAT_RG_1616: Int = 0x3a
internal const val IMAGE_FORMAT_RGBA_10101010: Int = 0x3b
